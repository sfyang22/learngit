#include<ESP8266wif.h>

extern void Uart();
/*���пڷ���*/
void Uart_SendByte(u8 dat)
{
	ES = 0;
	TI = 0;
	SBUF = dat;
	while(TI == 0);
	TI = 0;
	ES = 1;
}

void delay1(u8 a)
{
	u8 i;
	for(i=0;i<a;i++)
	{
		LCD_Show(0,0,"Connecting.  ");
		delay(30000);
		LCD_Show(0,0,"Connecting.. ");
		delay(30000);
		LCD_Show(0,0,"Connecting...");
		delay(30000);
		LCD_Show(0,0,"Connecting....");
		delay(30000);
		LCD_Show(0,0,"              ");
	}	
}

/*���������*/
void ESP8266_SendCmd(u8 *p)
{
	while(*p != '\0')
	{
		Uart_SendByte(*p);
		delay(5);
		p++;
	}
	delay(5);
	Uart_SendByte('\r');
	delay(5);
	Uart_SendByte('\n');
	delay1(5);
}


void ESP8266_GETTIME()
{
	u8 temp1,temp2;
	ESP8266_EN = 1;
	ESP8266_RST = 1;
	ESP8266_RST = 0;
	delay1(1);
	ESP8266_RST = 1;
	delay1(1);
	ESP8266_SendCmd("AT+RST");
	ESP8266_SendCmd("AT+CWMODE=1");	
	ESP8266_SendCmd("AT+CWJAP=\"esp\",\"66662222\"");
	delay1(8);
	ESP8266_SendCmd("AT+CWJAP=\"esp\",\"66662222\"");
	delay1(8);
	ESP8266_SendCmd("AT+CIPMUX=0");
	ESP8266_SendCmd("AT+CIPSTART=\"TCP\",\"api.k780.com\",80");
	ESP8266_SendCmd("AT+CIPMODE=1");
	ESP8266_SendCmd("AT+CIPSEND");
	ESP8266_SendCmd("GET http://api.k780.com:88/?app=life.time&appkey=10003&sign=b59bc3ef6191eb9f747dd4e83c99f2a4&format=json");
	delay1(10);

	temp1 = Rec[76] - '0';
	temp2 = Rec[77] - '0';

	if((temp1 >= 0 && temp1 <= 2) && ((temp2 >= 0) && temp2 <= 9))
	{
		TIME[2] |= temp1 << 4;
		TIME[2] |= temp2;			
	}
	else
	{
		flag = 1;
	}
	temp1 = Rec[79] - '0';
	temp2 = Rec[80] - '0';

	if((temp1 >= 0 && temp1 <= 5) && ((temp2 >= 0) && temp2 <= 9))
	{
		TIME[1] |= temp1 << 4;
		TIME[1] |= temp2;			
	}
	else
	{
		flag = 1;
	}

	temp1 = (Rec[82] - '0') + 1;
	temp2 = Rec[83] - '0' + 4;				
	if(temp2 > 9)
	{
		temp2 -= 10;
		temp1 += 1;
	}
	if(temp1 > 9)
	{
		temp1 -= 10;
		TIME[1] += 0x01;
	}

	if((temp1 >= 0 && temp1 <= 5) && ((temp2 >= 0) && temp2 <= 9))
	{
		TIME[0] |= temp1 << 4;
		TIME[0] |= temp2;			
	}
	else
	{
		flag = 1;
	}

	temp1 = Rec[145] - '0';

	if(temp1 >= 0 && temp1 <= 9)
	{
		TIME[5] = temp1;			
	}
	else
	{
		flag = 1;
	}

	DS1302Init();		//DS1302��ʼ��
	
	if(flag == 1)		//��ȡ����ʧ�ܱ�־λ
	{
		flag = 0;
		LCD_Show(0,0,"Fail!");
		delay(60000);
		LCD_Show(0,0,"        ");
		delay(20000);
		LCD_Show(0,0,"Fail!");
		delay(60000);
		delay(60000);
		delay(60000);
	}
	else
	{
		LCD_Show(0,0,"Success!       ");
		delay(60000);
		delay(60000);
		delay(60000);
		delay(60000);
		LCD_Show(0,0,"               ");

		
	}  

	ESP8266_EN = 0;
	ES = 0;
}


