#ifndef _DS1302_H_
#define _DS1302_H_

#include<intrins.h>

#ifndef u8
#define u8 unsigned char
#endif

#ifndef u16
#define u16 unsigned int
#endif

sbit DSIC = P3^5;
sbit RST = P3^6;
sbit SCLK = P3^7;

extern xdata READ_RTC_ADDR[7] = {0x81,0x83,0x85,0x87,0x89,0x8b,0x8d};
extern xdata WRITE_RTC_ADDR[7] = {0x80,0x82,0x84,0x86,0x88,0x8a,0x8c};
extern xdata TIME[7] = {0x00,0x00,0x00,0x24,0x02,0x01,0x20};

void DS1302Write(u8 addr,u8 dat);
u8 DS1302Read(u8 addr);
void DS1302Init();
void DS1302ReadTime();

#endif

