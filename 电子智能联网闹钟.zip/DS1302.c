#include<DS1302.h>

void DS1302Write(u8 addr,u8 dat)
{
	u8 n;
	RST = 0;
	_nop_();
	SCLK = 0;
	_nop_();
	RST = 1;
	_nop_();

	for(n=0;n<8;n++)
	{
		DSIC = addr & 0x01;
		addr >>= 1;
		SCLK = 1;
		_nop_();
		SCLK = 0;
		_nop_();	
	}

	for(n=0;n<8;n++)
	{
		DSIC = dat & 0x01;
		dat >>= 1;
		SCLK = 1;
		_nop_();
		SCLK = 0;
		_nop_();
	}
	
}

u8 DS1302Read(u8 addr)
{
	u8 i,dat,dat1;
	RST = 0;
	_nop_();
	
	SCLK = 0;
	_nop_();
	RST = 1;
	_nop_();
	
	for(i=0;i<8;i++)
	{
		DSIC = addr & 0x01;
		addr >>= 1;
		SCLK = 1;
		_nop_();
		SCLK = 0;
		_nop_();
	}	

	for(i=0;i<8;i++)
	{
		dat1 = DSIC;		 
		dat = (dat >> 1) | (dat1 << 7);	
		SCLK = 1;
		_nop_();
		SCLK = 0;
		_nop_();
	}
	
	RST = 0;
	_nop_();
	SCLK = 1;
	_nop_();
	SCLK = 0;
	_nop_();
	_nop_();
	
	return dat;	
}

void DS1302Init()
{
	u8 n;
	DS1302Write(0x8E,0x00);		//��ֹд���������ǹر�д��������
	for(n=0;n<7;n++)
	{
		DS1302Write(WRITE_RTC_ADDR[n],TIME[n]);
	}
	DS1302Write(0x8E,0x80);		//��д����

}

void DS1302ReadTime()
{
	u8 i;
	for(i=0;i<7;i++)
	{
		TIME[i] = DS1302Read(READ_RTC_ADDR[i]);
	}
}





